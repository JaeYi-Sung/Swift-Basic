
import Foundation
import UIKit

enum MaskParams {
    static let slope: CGFloat = 2.0 //4.0
    static let width: CGFloat = 0.2 //0.1
}

func createMask(for image: CVPixelBuffer, withFocus focus: CGFloat, withScale : Float) -> CIImage {
    let s1 = MaskParams.slope
    let s2 = -MaskParams.slope
    let filterWidth =  2 / MaskParams.slope + MaskParams.width
    let b1 = -s1 * (focus - filterWidth / 2)
    let b2 = -s2 * (focus + filterWidth / 2)
    
    var depthImage = CIImage(cvPixelBuffer: image) //.oriented(.left)
    print("depthImage : \(depthImage)")
    let mask0 = depthImage
        .applyingFilter("CIColorMatrix", parameters: [
            "inputRVector": CIVector(x: s1, y: 0, z: 0, w: 0),
            "inputGVector": CIVector(x: 0, y: s1, z: 0, w: 0),
            "inputBVector": CIVector(x: 0, y: 0, z: s1, w: 0),
            "inputBiasVector": CIVector(x: b1, y: b1, z: b1, w: 0)])
        .applyingFilter("CIColorClamp")
    
    let mask1 = depthImage
        .applyingFilter("CIColorMatrix", parameters: [
            "inputRVector": CIVector(x: s2, y: 0, z: 0, w: 0),
            "inputGVector": CIVector(x: 0, y: s2, z: 0, w: 0),
            "inputBVector": CIVector(x: 0, y: 0, z: s2, w: 0),
            "inputBiasVector": CIVector(x: b2, y: b2, z: b2, w: 0)])
        .applyingFilter("CIColorClamp")
    
    let combinedMask = mask0.applyingFilter("CIDarkenBlendMode", parameters: [
        "inputBackgroundImage": mask1
    ])
    var mask = combinedMask.applyingFilter("CIBicubicScaleTransform", parameters: [
        "inputScale": withScale
    ])
    
    var currentExtent = mask.extent
    let newExtent = CGRect(x: 0, y: 0, width: currentExtent.width, height: currentExtent.height)
    mask = mask.transformed(by: CGAffineTransform(translationX: -currentExtent.origin.x, y: -currentExtent.origin.y))
    
    return mask
}

func createSpotlightImage(for colorImage: CVPixelBuffer,
                          withDepth depthImage: CVPixelBuffer,
                          withFocus focus: CGFloat) -> UIImage? {
    let colorWidth = CVPixelBufferGetWidth(colorImage)
    let colorHeight = CVPixelBufferGetHeight(colorImage)
    let depthWidth = CVPixelBufferGetWidth(depthImage)
    let depthHeight = CVPixelBufferGetHeight(depthImage)
    let scale = Float(colorWidth) / Float(depthHeight)
    
    print("colorwidth : \(colorWidth)")
    print("depthwidth : \(depthWidth)")
    print("scale : \(scale)")
    var mask = createMask(for: depthImage,
                          withFocus: focus,
                          withScale: scale)
    print("mask : \(mask)")
    var colorCIImage = CIImage(cvPixelBuffer: colorImage)
    print("color : \(colorCIImage)")
    mask = mask.oriented(.left)
    print("resizemask : \(mask)")
    let output = colorCIImage.applyingFilter("CIBlendWithMask", parameters: [
        "inputMaskImage": mask
    ])
    
    let context = CIContext()
    guard let cgImage = context.createCGImage(output, from: output.extent) else {
        return nil
    }
    return UIImage(cgImage: cgImage, scale: 1, orientation: .right)
}

func createColorHighlight(for colorImage: CVPixelBuffer,
                          withDepth depthImage: CVPixelBuffer,
                          withFocus focus: CGFloat) -> UIImage? {
    let colorWidth = CVPixelBufferGetWidth(colorImage)
    let colorHeight = CVPixelBufferGetHeight(colorImage)
    let depthWidth = CVPixelBufferGetWidth(depthImage)
    let depthHeight = CVPixelBufferGetHeight(depthImage)
    let scale = Float(colorWidth) / Float(depthHeight)
    var mask = createMask(for: depthImage,
                          withFocus: focus,
                          withScale: scale)
    let grayscale = CIImage(cvPixelBuffer: colorImage).applyingFilter("CIPhotoEffectMono")
    let output = CIImage(cvPixelBuffer: colorImage).applyingFilter("CIBlendWithMask", parameters: [
        "inputBackgroundImage" : grayscale,
        "inputMaskImage": mask
    ])
    let context = CIContext()
    guard let cgImage = context.createCGImage(output, from: output.extent) else {
        return nil
    }
    
    return UIImage(cgImage: cgImage, scale: 1, orientation: .right)
}

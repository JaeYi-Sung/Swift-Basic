
import UIKit
import ARKit
import Vision
import CoreVideo
import CoreImage

class ViewController: UIViewController, ARSessionDelegate, ARSCNViewDelegate {

    //MARK: Outlets
    private var arView : ARSCNView!
    private var saliencyView : UIImageView!
    private var filteredView : UIImageView!
    
    //MARK: Variables
    private var isAttentionMode = true //If False, ObjectnessBased
    
    //MARK: View Did Load
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    //MARK: View Did Appear
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //Init ARView
        initARView()
        
        //Init Image View
        initImageViews()
    }
    
    //MARK: Init ARView
    private func initARView() {
        arView = ARSCNView(frame: CGRect(x: 0,
                                         y: 0,
                                         width: view.frame.width * 0.5,
                                         height: view.frame.height * 0.5))
        arView.scene = SCNScene()
        arView.session = ARSession()
        let config = ARWorldTrackingConfiguration()
        config.frameSemantics = .sceneDepth
        arView.session.run(config)
        view.addSubview(arView)
        
        arView.delegate = self
        arView.session.delegate = self
    }
    
    //MARK: Init Image Views
    private func initImageViews() {
        //Saliency View
        saliencyView = UIImageView(frame: CGRect(x: view.frame.width / 2,
                                                 y: 0,
                                                 width: view.frame.width / 2,
                                                 height: view.frame.height / 2))
        saliencyView.backgroundColor = .black
        saliencyView.contentMode = .scaleAspectFit
        view.addSubview(saliencyView)
        
        //Filtered View
        filteredView = UIImageView(frame: CGRect(x: view.frame.width / 2,
                                                 y: view.frame.height / 2,
                                                 width: view.frame.width / 2,
                                                 height: view.frame.height / 2))
        filteredView.backgroundColor = .black
        filteredView.contentMode = .scaleAspectFit
        view.addSubview(filteredView)
    }
    
    //MARK: Process Saliency
    private func processSaliency(on pixelBuffer : CVPixelBuffer) {
        //Saliency Image
        let reqHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .right, options: [:])
        let req : VNRequest
        if isAttentionMode {
            req = VNGenerateAttentionBasedSaliencyImageRequest()
        } else {
            req = VNGenerateObjectnessBasedSaliencyImageRequest()
        }
        
        req.revision = 1
        
        try? reqHandler.perform([req])
        let observation = req.results?.first as? VNSaliencyImageObservation
        
        let observation_pixelBuffer = observation!.pixelBuffer
        let ciImage = CIImage(cvPixelBuffer: observation_pixelBuffer)
        let vector = CIVector(x: 0, y: 0, z: 0, w: 1)
        let saliencyImage = ciImage.applyingFilter("CIColorMatrix", parameters: ["inputBVector": vector])
        let heatMapMask = CIContext().createCGImage(saliencyImage, from: saliencyImage.extent)
//        let heatMapUIImage = UIImage(cgImage: heatMapMask!,
//                                     scale: 1.0,
//                                     orientation: .rightMirrored)
        let heatMapUIImage = UIImage(ciImage: CIImage(cvPixelBuffer: observation_pixelBuffer),
                                     scale: 1.0,
                                     orientation: .right)
                
        DispatchQueue.main.async {
            self.saliencyView.image = heatMapUIImage
        }
        
        //Filter Image
        observation_pixelBuffer.normalize()
        let resize_observation_pixelBuffer =
        observation_pixelBuffer.resizePixelBuffer(targetWidth: 1440, targetHeight: 1920)
        let blendImage = createSpotlightImage(for: pixelBuffer,
                                              withDepth: resize_observation_pixelBuffer!,
                                              withFocus: 0.65)!
        
        DispatchQueue.main.async {
            self.filteredView.image = blendImage
        }
    }
    
    
    //MARK: -Delegates
    var saliencyFrameCount = 0
    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        let color = frame.capturedImage
        saliencyFrameCount += 1
        if saliencyFrameCount % 10 == 0 {
            processSaliency(on: color)
        }
    }
}


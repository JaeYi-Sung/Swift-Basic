//
//  CIImage+Extensions.swift
//  Saliency_RegionOfInterst
//
//  Created by HEOJIN on 2/16/23.
//

import Foundation
import CoreGraphics
import CoreImage

func resizeCIImage(_ image: CIImage, newSize: CGSize) -> CIImage? {
    let scale = newSize.width / image.extent.width
    let transform = CGAffineTransform(scaleX: scale, y: scale)
    let outputImage = image.transformed(by: transform)
    return outputImage
}

func resizeAndRatioCIImage(image: CIImage, newWidth: CGFloat, newHeight: CGFloat) -> CIImage {
    let currentExtent = image.extent
    
    let currentAspectRatio = currentExtent.width / currentExtent.height
    let newAspectRatio = newWidth / newHeight
    
    let scaleX = newWidth / currentExtent.width
    let scaleY = newHeight / currentExtent.height
    
    var paddingX: CGFloat = 0
    var paddingY: CGFloat = 0
    
    if currentAspectRatio < newAspectRatio {
        paddingX = (newWidth - currentExtent.width * scaleY) / 2
    } else if currentAspectRatio > newAspectRatio {
        paddingY = (newHeight - currentExtent.height * scaleX) / 2
    }
    
    let transform = CGAffineTransform(scaleX: scaleX, y: scaleY).translatedBy(x: paddingX, y: paddingY)
    
    return image.transformed(by: transform)
}

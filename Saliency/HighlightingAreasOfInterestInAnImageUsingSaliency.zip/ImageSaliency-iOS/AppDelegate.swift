/*
See LICENSE folder for this sample’s licensing information.

Abstract:
iOS app delegate, declares UIWindow "window"
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

}


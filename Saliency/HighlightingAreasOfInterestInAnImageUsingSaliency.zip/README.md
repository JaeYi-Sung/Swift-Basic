# Highlighting Areas of Interest in an Image Using Saliency

Quantify and visualize where people are likely to look in an image.

## Overview

- Note: For more information about this sample code project, see [WWDC 2019 Session 222: Understanding Images in Vision Framework](https://developer.apple.com/videos/play/wwdc19/222/).
